Applying a patch for MES Model Examiner�
----------------------------------------

1) Close MXAM.
2) Copy the patch zip-file into your MXAM installation directory.
3) Unzip the file "to here".
4) Confirm to overwrite files if required.


A .patch file with a documentation will be placed into the installation directory for each patch to track all applied patches.